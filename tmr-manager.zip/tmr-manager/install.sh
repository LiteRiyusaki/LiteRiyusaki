mount -o rw,remount /

cp -f -R /storage/emulated/0/tmr-manager/tmrman /data/system

cp -f /storage/emulated/0/tmr-manager/bin/tmrman /system/bin

if [ ! -d "/data/system/tmrman" ];then echo "could not complete";exit 1;fi

if [ -f "/system/bin/tmrman" ]; then chmod 755 /system/bin/tmrman;echo "done";else echo "unable to complete"; exit 2; fi
